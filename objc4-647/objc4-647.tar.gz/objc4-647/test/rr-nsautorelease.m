// TEST_CFLAGS -framework Foundation
// TEST_CONFIG MEM=mrc

#define FOUNDATION 1
#define NAME "rr-nsautorelease"

#include "rr-autorelease2.m"
